@echo off
setlocal

where ml.exe >nul 2>nul
if errorlevel 1 (
  echo [ERROR] ml.exe tidak ditemukan.
  echo Jalankan file ini dari "x86 Native Tools Command Prompt for VS".
  exit /b 1
)

where link.exe >nul 2>nul
if errorlevel 1 (
  echo [ERROR] link.exe tidak ditemukan.
  echo Jalankan file ini dari "x86 Native Tools Command Prompt for VS".
  exit /b 1
)

echo [1/2] Assembling x86...
ml.exe /nologo /c /coff x86_hello.asm
if errorlevel 1 (
  echo Assembly gagal.
  exit /b 1
)

echo [2/2] Linking x86 PE/COFF...
link.exe /nologo /subsystem:console /machine:x86 x86_hello.obj kernel32.lib /out:x86_hello.exe
if errorlevel 1 (
  echo Linking gagal.
  exit /b 1
)

echo.
echo Build berhasil: x86_hello.exe
echo Menjalankan program...
echo.
x86_hello.exe
endlocal
