; ASM Studio - MASM x86 (32-bit Windows Console)
; Requires Visual Studio Build Tools / Visual Studio "x86 Native Tools Command Prompt".
; Build with build_x86.bat.

.386
.model flat, stdcall
option casemap:none

includelib kernel32.lib

STD_OUTPUT_HANDLE EQU -11

.data
message     db "Hello from Assembly x86!", 13, 10
messageLen  equ ($ - message)
written     dd 0

.code
EXTERN GetStdHandle@4:PROC
EXTERN WriteFile@20:PROC
EXTERN ExitProcess@4:PROC

main PROC
    push STD_OUTPUT_HANDLE
    call GetStdHandle@4

    push 0
    push offset written
    push messageLen
    push offset message
    push eax
    call WriteFile@20

    push 0
    call ExitProcess@4
main ENDP

END main
