# ASM Studio

**ASM Studio** adalah compiler/emulator **8086 / MS-DOS** dan editor/validator source **Assembly x86 (MASM 32-bit)** berbasis JavaScript yang berjalan langsung di browser.

## 👤 Author

**Bahrizal Helmi Mulyawan**

## ✨ Fitur

- 🖥️ Compiler Assembly 8086
- 🧩 Target Assembly X86 (MASM 32-bit) dengan `.model flat, stdcall`
- 🪟 Contoh Windows x86 yang dapat di-build menjadi `.exe`
- ⚙️ Emulator CPU 8086
- 📝 Editor kode Assembly
- 🛠️ Build Code
- ▶️ Menjalankan program
- ⏭️ Step-by-step execution
- 🔄 Reset CPU
- 🐛 Panel Build / Debug
- 📋 Register CPU
- 🔖 Simbol / Label
- 📚 Call Stack
- 💾 Memory Dump
- 📟 Output MS-DOS
- 📦 Download `.COM`, `.BIN`, dan `.HEX`
- 🌐 Bahasa GUI: Indonesia, India, Malaysia, English
- 🎨 Tema: Light, Dark, Hacker, Random

## 📥 Tutorial Instalasi

ASM Studio merupakan aplikasi HTML yang dapat dijalankan langsung menggunakan browser.

### 1. Download repository

Clone repository menggunakan Git atau download repository melalui **Code → Download ZIP** di GitHub.

### 2. Extract file

Pastikan file utama berikut tersedia:

```text
index.html
```

### 3. Jalankan ASM Studio

Buka file HTML tersebut dengan browser seperti Google Chrome, Mozilla Firefox, atau Microsoft Edge.

### 4. Selesai 🎉

Tidak diperlukan instalasi compiler Assembly atau emulator 8086 tambahan untuk menjalankan aplikasi ini.

## 🚀 Cara Menggunakan

1. Tulis kode Assembly 8086 pada editor.
2. Klik **🛠 Build Code (F9)** untuk melakukan assembly.
3. Untuk target 8086, klik **▶ Jalankan Emulator (F5)**.
4. Untuk target **Assembly X86 (MASM 32-bit)**, klik **Build Code** untuk validasi source, lalu jalankan `build_x86.bat` dari **x86 Native Tools Command Prompt for VS** untuk menghasilkan dan menjalankan `x86_hello.exe`.
5. Gunakan **F10** untuk menjalankan instruksi 8086 satu per satu.
6. Gunakan **Reset CPU** untuk mengembalikan kondisi emulator 8086.

### Assembly X86 (MASM 32-bit)

Target **Assembly X86** menggunakan format MASM Windows 32-bit:

```asm
.386
.model flat, stdcall
option casemap:none
```

Source contoh tersedia di `x86_hello.asm`. Pada Windows dengan Visual Studio Build Tools, buka **x86 Native Tools Command Prompt for VS**, masuk ke folder proyek, lalu jalankan:

```bat
build_x86.bat
```

Script tersebut menjalankan `ml.exe` untuk assembly dan `link.exe` untuk menghasilkan PE/COFF `x86_hello.exe`, kemudian menjalankannya.

> Browser tidak dapat mengeksekusi file `.exe` native karena sandbox keamanan. Karena itu target x86 divalidasi di ASM Studio, sedangkan proses assemble/link/run native dilakukan oleh `build_x86.bat` di Windows.

Segitiga Pascal:
        1
       1 1
      1 2 1
     1 3 3 1
    1 4 6 4 1


Fibonacci (8 langkah)
Nilai akhir = 21
AX = 21 (0x0015)
Deret: 0, 1, 1, 2, 3, 5, 8, 13, 21
Program Selesai.

## 🌐 Bahasa GUI

Tersedia empat pilihan:

- 🇮🇩 Indonesia
- 🇮🇳 India
- 🇲🇾 Malaysia
- 🇬🇧 English

## 🎨 Tema

- **Light**
- **Dark**
- **Hacker**
- **Random**

## ⌨️ Shortcut Keyboard

| Shortcut | Fungsi |
|---|---|
| `F5` | Menjalankan Emulator |
| `F9` | Build Code |
| `F10` | Step / menjalankan satu instruksi |

## 🛠️ Teknologi

- HTML
- CSS
- JavaScript
- 8086 Assembly
- Emulator CPU 8086 berbasis JavaScript

## 👨‍💻 Author

**Bahrizal Helmi Mulyawan**



ASM Studio — Learn 8086 Assembly by seeing the CPU execute it. ⚡

🌐 Live Demo

https://bahrizalmulyawan.github.io/ASM_Studio/





<img width="1029" height="627" alt="Screenshot_1" src="https://github.com/user-attachments/assets/3ba12988-c4b5-4695-9395-844a91f392a8" />
<img width="820" height="628" alt="Screenshot_2" src="https://github.com/user-attachments/assets/5cbda308-f151-47cf-b319-9a225cbc9951" />

